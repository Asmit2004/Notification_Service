




const express = require('express');
const bodyParser = require('body-parser');
const amqp = require('amqplib');
const { v4: uuidv4 } = require('uuid');

const app = express();
const PORT = 3000;

app.use(bodyParser.json());

app.get('/', (req, res) => {
    res.send('Notification Service is running!');
});

const notifications = {}; 

let channel;
const queue = 'notificationQueue';

async function connectQueue() {
    const connection = await amqp.connect('amqp://localhost');
    channel = await connection.createChannel();
    await channel.assertQueue(queue);
}

connectQueue().then(() => {
    console.log('Connected to RabbitMQ');
    startConsumer();
});

function startConsumer() {
    channel.consume(queue, async (msg) => {
        const notification = JSON.parse(msg.content.toString());
        try {
            await sendNotification(notification);
            channel.ack(msg);
        } catch (err) {
            console.error('Retrying notification due to error:', err.message);
            retryNotification(notification, msg.fields.redelivered);
        }
    });
}

async function retryNotification(notification, redelivered) {
    if (redelivered) {
        console.error('Failed after retry:', notification);
        return;
    }
    setTimeout(() => {
        channel.sendToQueue(queue, Buffer.from(JSON.stringify(notification)));
    }, 2000); 
}

async function sendNotification({ userId, type, message }) {
    if (!['email', 'sms', 'inapp'].includes(type)) throw new Error('Invalid type');
    console.log(`[SENDING ${type.toUpperCase()}] to ${userId}: ${message}`);

    const userNotif = {
        id: uuidv4(),
        userId,
        type,
        message,
        timestamp: new Date()
    };
    if (!notifications[userId]) notifications[userId] = [];
    notifications[userId].push(userNotif);
}

app.post('/notifications', async (req, res) => {
    const { userId, type, message } = req.body;
    if (!userId || !type || !message) {
        return res.status(400).send({ error: 'Missing required fields' });
    }
    channel.sendToQueue(queue, Buffer.from(JSON.stringify({ userId, type, message })));
    res.send({ status: 'Notification queued' });
});

app.get('/users/:id/notifications', (req, res) => {
    const userId = req.params.id;
    res.send(notifications[userId] || []);
});

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
